#ifndef _REALTIME_CURVATURE_H_
#define _REALTIME_CURVATURE_H_

#include <cuda_runtime_api.h>
#include <cutil_math.h>

__device__
void computeNormals(float3 vt[3], float2 tx[2], float* normal_area, size_t map_width, size_t map_height);

__device__
void computeInitialCoordinateSystem(float3 vt[3], float2 tx[2], float* normal_area, int* flags,
									float* initial_max, float* initial_min, size_t map_width, size_t map_height);

__device__
void computeCurvature(float3 vt[3], float2 tx[2], float* normal_area, float* initial_max, float* initial_min,
					  float* curvature, size_t map_width, size_t map_height);

__device__
void computePrincipalDirections(float2 tx, float* normal_area, float* curvature, float* initial_max, float* initial_min, int* flags,
								float* max, float* min, size_t map_width, size_t map_height);

__device__
void computeDifferential(float3 vt[3], float2 tx[3], float* normal_area, float* max, float* min,
						 float* differential, size_t map_width, size_t map_height);

#endif // _REALTIME_CURVATURE_H_