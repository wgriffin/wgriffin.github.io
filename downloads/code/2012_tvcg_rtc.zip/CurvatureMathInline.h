#ifndef _CURVATURE_MATH_INLINE_H_
#define _CURVATURE_MATH_INLINE_H_

inline __device__
int computeOffset(float2 t, size_t map_width, size_t map_height) {
	const int x = (int)(t.x * map_width);
	const int y = (int)(t.y * map_height);
	return x + y * map_width;
}

inline __device__
void lookupNormals(float2 t[3], size_t map_width, size_t map_height, float4* normal_area, float3 N[3]) {
	for (int index = 0; index < 3; index++) {
		const int offset = computeOffset(t[index], map_width, map_height);
		const float4 vec = normal_area[offset];
		N[index] = normalize(make_float3(vec.x, vec.y, vec.z));
	}
}

inline __device__
void lookupNormalsAreas(float2 t[3], size_t map_width, size_t map_height, float4* normal_area, float3 N[3], float A[3]) {
	for (int index = 0; index < 3; index++) {
		const int offset = computeOffset(t[index], map_width, map_height);
		const float4 vec = normal_area[offset];
		N[index] = normalize(make_float3(vec.x, vec.y, vec.z));
		A[index] = vec.w;
	}
}

inline __device__
void lookupAreas(float2 t[3], size_t map_width, size_t map_height, float4* normal_area, float A[3]) {
	for (int index = 0; index < 3; index++) {
		const int offset = computeOffset(t[index], map_width, map_height);
		A[index] = normal_area[offset].w;
	}
}

inline __device__
int PREV(int index) {
    return (index > 0) ? index - 1 : index + 2;
}

inline __device__
int NEXT(int index) {
    return (index < 2) ? index + 1 : index - 2;
}

inline __device__
void edges(float3 v0, float3 v1, float3 v2, float3 e[3]) {
    e[0] = v2 - v1;
    e[1] = v0 - v2;
    e[2] = v1 - v0;
}

inline __device__
//float3 compute_corner_area(float3 e[3]) {
float3 compute_corner_area(float3 v0, float3 v1, float3 v2) {
	float3 e[3];
    e[0] = v2 - v1;
    e[1] = v0 - v2;
    e[2] = v1 - v0;

	float l2[3] = { 0.0f, 0.0f, 0.0f };
    for (int index = 0; index < 3; index++) {
        l2[index] = dot(e[index], e[index]);
    }

	float ew[3] = { 0.0f, 0.0f, 0.0f };
    for (int index = 0; index < 3; index++) {
        int next1 = (index + 1) % 3;
        int next2 = (index + 2) % 3;
        ew[index] = l2[index] * (l2[next1] + l2[next2] - l2[index]);
    }

    float area = 0.5f * length(cross(e[0], e[1]));
    float3 corner_area;
	if (ew[0] <= 0.0f) {
		corner_area.y = -0.25f * l2[2] * area / dot(e[0], e[2]);
		corner_area.z = -0.25f * l2[1] * area / dot(e[0], e[1]);
		corner_area.x = area - corner_area.y - corner_area.z;
	} else if (ew[1] <= 0.0f) {
		corner_area.z = -0.25f * l2[0] * area / dot(e[1], e[0]);
		corner_area.x = -0.25f * l2[2] * area / dot(e[1], e[2]);
		corner_area.y = area - corner_area.z - corner_area.x;
	} else if (ew[2] <= 0.0f) {
		corner_area.x = -0.25f * l2[1] * area / dot(e[2], e[1]);
		corner_area.y = -0.25f * l2[0] * area / dot(e[2], e[0]);
		corner_area.z = area - corner_area.x - corner_area.y;
	} else {
		float ewscale = 0.5f * area / (ew[0] + ew[1] + ew[2]);
		corner_area.x = ewscale * (ew[1] + ew[2]);
		corner_area.y = ewscale * (ew[2] + ew[0]);
		corner_area.z = ewscale * (ew[0] + ew[1]);
	}

    return corner_area;
}

inline __device__
void rotate_coordinate_system(float3 old_u, float3 old_v, float3 new_norm, float3 *rot_u, float3 *rot_v) {
	*rot_u = old_u;
	*rot_v = old_v;
	float3 old_norm = cross(old_u, old_v);
	
	float ndot = dot(old_norm, new_norm);
	if (ndot <= -1.0f) {
		*rot_u = -(*rot_u);
		*rot_v = -(*rot_v);
	} else {
		float3 perp_old = new_norm - ndot * old_norm;
		float3 dperp = 1.0f / (1.0f + ndot) * (old_norm + new_norm);
		*rot_u -= dperp * dot(*rot_u, perp_old);
		*rot_v -= dperp * dot(*rot_v, perp_old);
	}
}

// Perform LDL^T decomposition of a symmetric positive definite 3x3 matrix.
// Overwrites lower triangle of matrix.
inline __device__
void ldltdc3(float A[3][3], float rdiag[3]) {
	float v[2] = { 0.0f, 0.0f };

	for (int i = 0; i < 3; i++) {
      for (int k = 0; k < i; k++) v[k] = A[i][k] * rdiag[k];
      for (int j = i; j < 3; j++) {
          float sum = A[i][j];
          for (int l = 0; l < i; l++) sum -= v[l] * A[j][l];
          if (i == j) rdiag[i] = 1.0f / sum;
          else A[j][i] = sum;
		}
	}
}

// Perform LDL^T decomposition of a symmetric positive definite 4x4 matrix.
// Overwrites lower triangle of matrix.
inline __device__
void ldltdc4(float A[4][4], float rdiag[4]) {
	float v[3] = { 0.0f, 0.0f };

	for (int i = 0; i < 4; i++) {
        for (int k = 0; k < i; k++) v[k] = A[i][k] * rdiag[k];
        for (int j = i; j < 4; j++) {
			float sum = A[i][j];
			for (int l = 0; l < i; l++) sum -= v[l] * A[j][l];
			if (i == j) rdiag[i] = 1.0 / sum;
			else A[j][i] = sum;
		}
	}
}

// Solve Ax=B after ldltdc.
inline __device__
void ldltsl3(float A[3][3], float rdiag[3], float B[3], float x[3]) {
    for (int i = 0; i < 3; i++) {
        float sum = B[i];
        for (int k = 0; k < i; k++) sum -= A[i][k] * x[k];
		x[i] = sum * rdiag[i];
	}
	for (int j = 2; j >= 0; j--) {
		float sum = 0;
		for (int k = j + 1; k < 3; k++) sum += A[k][j] * x[k];
		x[j] -= sum * rdiag[j];
	}
}

// Solve Ax=B after ldltdc.
inline __device__
void ldltsl4(float A[4][4], float rdiag[4], float B[4], float x[4]) {
    for (int i = 0; i < 4; i++) {
        float sum = B[i];
        for (int k = 0; k < i; k++) sum -= A[i][k] * x[k];
		x[i] = sum * rdiag[i];
	}
	for (int j = 3; j >= 0; j--) {
		float sum = 0;
		for (int k = j + 1; k < 4; k++) sum += A[k][j] * x[k];
		x[j] -= sum * rdiag[j];
	}
}

inline __device__
float3 project_curvature(float3 old_u, float3 old_v, float old_k[3], float3 new_u, float3 new_v) {
	float3 rot_u = make_float3(0.0f);
	float3 rot_v = make_float3(0.0f);
	rotate_coordinate_system(new_u, new_v, cross(old_u, old_v), &rot_u, &rot_v);
	
	const float u1 = dot(rot_u, old_u);
	const float v1 = dot(rot_u, old_v);
	const float u2 = dot(rot_v, old_u);
	const float v2 = dot(rot_v, old_v);

	return make_float3(
		old_k[0] * u1 * u1 + old_k[1] * (2.0f * u1 * v1) + old_k[2] * v1 * v1,
		old_k[0] * u1 * u2 + old_k[1] * (u1 * v2 + u2 * v1) + old_k[2] * v1 * v2,
		old_k[0] * u2 * u2 + old_k[1] * (2.0f * u2 * v2) + old_k[2] * v2 * v2
	);
}

inline __device__
float4 project_differential(float3 old_u, float3 old_v, float old_dcurv[4], float3 new_u, float3 new_v) {
	float3 rot_u = make_float3(0.0f);
	float3 rot_v = make_float3(0.0f);
	rotate_coordinate_system(new_u, new_v, cross(old_u, old_v), &rot_u, &rot_v);
	
	const float u1 = dot(rot_u, old_u);
	const float v1 = dot(rot_u, old_v);
	const float u2 = dot(rot_v, old_u);
	const float v2 = dot(rot_v, old_v);

	return make_float4(
		old_dcurv[0] * u1 * u1 * u1 +
			old_dcurv[1] * 3.0f * u1 * u1 * v1 +
			old_dcurv[2] * 3.0f * u1 * v1 * v1 +
			old_dcurv[3] * v1 * v1 * v1,
		old_dcurv[0] * u1 * u1 * u2 +
			old_dcurv[1] * (u1 * u1 * v2 + 2.0 * u2 * u1 * v1) +
			old_dcurv[2] * (u2 * v1 * v1 + 2.0 * u1 * v1 * v2) +
			old_dcurv[3] * v1 * v1 * v2,
		old_dcurv[0] * u1 * u2 * u2 +
			old_dcurv[1] * (u2 * u2 * v1 + 2.0 * u1 * u2 * v2) +
			old_dcurv[2] * (u1 * v2 * v2 + 2.0 * u2 * v2 * v1) +
			old_dcurv[3] * v1 * v2 * v2,
		old_dcurv[0] * u2 * u2 * u2 +
			old_dcurv[1] * 3.0f * u2 * u2 * v2 +
			old_dcurv[2] * 3.0f * u2 * v2 * v2 +
			old_dcurv[3] * v2 * v2 * v2
	);
}


#endif