#ifndef _CURVATURE_MATH_H_
#define _CURVATURE_MATH_H_

#include <cuda_runtime_api.h>
#include <cutil_math.h>

inline __device__
int PREV(int index) {
    return (index > 0) ? index - 1 : index + 2;
}

inline __device__
int NEXT(int index) {
    return (index < 2) ? index + 1 : index - 2;
}

__device__
void edges(float3 v0, float3 v1, float3 v2, float3 e[3]);

__device__
float3 compute_corner_area(float3 v0, float3 v1, float3 v2);

__device__
void initial_coordinate_system(float3 v0, float3 v1, float3 v2, float3 n0, float3 n1, float3 n2, float3 dir1[3], float3 dir2[3]);

__device__
void rotate_coordinate_system(float3 old_u, float3 old_v, float3 new_norm, float3& rot_u, float3& rot_v);

__device__
void ldltdc3(float A[3][3], float rdiag[3]);

__device__
void ldltdc4(float A[4][4], float rdiag[4]);

__device__
void ldltsl3(float A[3][3], float rdiag[3], float B[3], float x[3]);

__device__
void ldltsl4(float A[4][4], float rdiag[4], float B[4], float x[4]);

__device__
float3 project_curvature(float3 old_u, float3 old_v, float old_k[3], float3 new_u, float3 new_v);

__device__
float4 project_differential(float3 old_u, float3 old_v, float old_dcurv[4], float3 new_u, float3 new_v);

#endif // _CURVATURE_MATH_H_
